package com.newzy.backend.domain.news.dto.response;

public class NewsDetailGetResponseDto {
}
