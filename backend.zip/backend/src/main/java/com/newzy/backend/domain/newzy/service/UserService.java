package com.newzy.backend.domain.newzy.service;

public interface UserService {
}
