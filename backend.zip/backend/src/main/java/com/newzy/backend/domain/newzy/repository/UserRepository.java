//package com.newzy.backend.domain.newzy.repository;
//
//public interface UserRepository {
//}
