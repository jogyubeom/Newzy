//package com.newzy.backend.domain.newzy.dto.request;
//
//import io.swagger.v3.oas.annotations.media.Schema;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.RequiredArgsConstructor;
//import lombok.Setter;
//
//import java.time.LocalDate;
//
//@Getter
//@Setter
//@RequiredArgsConstructor
//@AllArgsConstructor
//@Schema(title = "USER_REQ : 유저 요청 DTO")
//public class UseRequestDTO {
//
//}